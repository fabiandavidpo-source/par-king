import assert from 'node:assert/strict';
import { existsSync, mkdtempSync, readFileSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';

import { build } from '../build.mjs';
import { iconNames } from '../src/icons.mjs';
import { pickLanguage } from '../src/lang.mjs';
import { PAGES } from '../src/render.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const contentDir = join(here, '..', 'src', 'content');
const content = Object.fromEntries(readdirSync(contentDir).map((f) => [f.replace('.json', ''), JSON.parse(readFileSync(join(contentDir, f), 'utf8'))]));
const out = mkdtempSync(join(tmpdir(), 'par-king-web-'));
const result = build({ outDir: out, siteUrl: 'https://par-king.test', year: 2026 });
const html = (rel) => readFileSync(join(out, rel), 'utf8');

/** Forma de un objeto: las claves y el largo de las listas deben coincidir entre idiomas. */
const shape = (v) => (Array.isArray(v) ? v.map(shape) : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, shape(v[k])])) : typeof v);

test('todos los idiomas tienen exactamente las mismas claves y listas del mismo largo', () => {
  const [first, ...rest] = Object.keys(content);
  for (const code of rest) assert.deepEqual(shape(content[code]), shape(content[first]), `${code} difiere de ${first}`);
});

test('ningún texto está vacío ni quedó sin traducir (igual al otro idioma, salvo marcas y cifras)', () => {
  const texts = (v, path = '') => (typeof v === 'string' ? [[path, v]] : Object.entries(v).flatMap(([k, x]) => texts(x, `${path}.${k}`)));
  const es = new Map(texts(content.es));
  for (const [path, value] of texts(content.en)) {
    assert.ok(value.trim().length > 0, `vacío: ${path}`);
    const same = es.get(path) === value;
    const exempt = /name|short|code|locale|price|time$|\.icon$|total|ios|android|tagline/.test(path) || /^[\d$.,\s/hs]+$/.test(value) || value === 'par-king';
    assert.ok(!same || exempt, `sin traducir: ${path} = ${value}`);
  }
});

test('los iconos que usa el contenido existen', () => {
  const used = JSON.stringify(content).match(/"icon":"(\w+)"/g).map((m) => m.slice(8, -1));
  for (const name of used) assert.ok(iconNames.includes(name), `icono faltante: ${name}`);
});

test('se genera cada página en cada idioma, con su idioma declarado y sin restos de plantilla', () => {
  assert.deepEqual(result.languages.sort(), ['en', 'es']);
  for (const lang of result.languages) {
    for (const { file } of PAGES) {
      const page = html(`${lang}/${file}`);
      assert.match(page, new RegExp(`<html lang="${lang}">`));
      assert.match(page, /<title>[^<]+<\/title>/);
      assert.match(page, /<meta name="description" content="[^"]+">/);
      assert.equal((page.match(/<h1[ >]/g) ?? []).length, 1, `${lang}/${file}: debe tener un solo h1`);
      assert.doesNotMatch(page, /undefined|\[object|\{\{|NaN/);
    }
  }
});

test('todos los enlaces y recursos internos existen', () => {
  const pages = [...result.files];
  for (const rel of pages) {
    const base = dirname(join(out, rel));
    for (const m of html(rel).matchAll(/(?:href|src)="([^"]+)"/g)) {
      const target = m[1];
      if (/^(https?:|mailto:|#|data:)/.test(target)) continue;
      assert.ok(existsSync(resolve(base, target.split('#')[0])), `${rel} enlaza a ${target}, que no existe`);
    }
  }
});

test('el sitio no carga nada de terceros (ni fuentes, ni scripts, ni imágenes externas)', () => {
  for (const rel of result.files) {
    for (const m of html(rel).matchAll(/(?:src|href)="(https?:\/\/[^"]+)"/g)) {
      assert.match(m[1], /^https:\/\/par-king\.test\//, `${rel} usa un recurso externo: ${m[1]}`);
    }
  }
  assert.doesNotMatch(readFileSync(join(out, 'assets', 'styles.css'), 'utf8'), /@import|url\(\s*['"]?https?:/);
});

test('cada página enlaza a la misma página en el otro idioma, y marca hreflang con SITE_URL', () => {
  for (const { file } of PAGES) {
    assert.match(html(`es/${file}`), new RegExp(`href="\\.\\./en/${file}"[^>]*hreflang="en"`));
    assert.match(html(`en/${file}`), new RegExp(`href="\\.\\./es/${file}"[^>]*hreflang="es"`));
    assert.match(html(`es/${file}`), new RegExp(`rel="canonical" href="https://par-king.test/es/${file}"`));
  }
  assert.match(readFileSync(join(out, 'sitemap.xml'), 'utf8'), /https:\/\/par-king\.test\/en\/about\.html/);
});

test('las páginas piden lo prometido: misión, visión, inicio, reservar y dueños; sin cifras ni opiniones inventadas', () => {
  assert.match(html('es/about.html'), /Misión/);
  assert.match(html('es/about.html'), /Visión/);
  assert.match(html('es/how-it-works.html'), /Reserva en segundos/);
  assert.match(html('es/owners.html'), /dueños/i);
  assert.match(html('en/how-it-works.html'), /Book in seconds/);
  for (const rel of result.files) assert.doesNotMatch(html(rel), /testimonio|testimonial|\d+\s?(mil|k)?\+?\s?(usuarios|users|downloads|descargas)/i);
});

test('la app aún no está publicada: las tiendas no son enlaces', () => {
  const home = html('es/index.html');
  assert.match(home, /aria-disabled="true"/);
  assert.doesNotMatch(home, /apps\.apple\.com|play\.google\.com/);
});

test('pickLanguage elige según el dispositivo', () => {
  const sup = ['es', 'en'];
  assert.equal(pickLanguage(['en-US'], sup, 'es'), 'en');
  assert.equal(pickLanguage(['es-CO', 'en'], sup, 'es'), 'es');
  assert.equal(pickLanguage(['EN_gb'], sup, 'es'), 'en');
  assert.equal(pickLanguage(['fr-FR', 'en-GB'], sup, 'es'), 'en'); // el primero que tenga sitio
  assert.equal(pickLanguage(['pt-BR', 'de'], sup, 'es'), 'es'); // ninguno: por defecto
  assert.equal(pickLanguage([], sup, 'es'), 'es');
  assert.equal(pickLanguage(undefined, sup, 'es'), 'es');
});

test('la página de entrada incluye la función tal cual y redirige', () => {
  const root = html('index.html');
  assert.match(root, /function pickLanguage/);
  assert.match(root, /location\.replace/);
  assert.match(root, /par-king\.lang/);
  // Ejecuta el script de la entrada simulando un dispositivo.
  const script = root.match(/<script>([\s\S]*?)<\/script>/)[1];
  const run = (languages, saved) => {
    let target = null;
    const fn = new Function('navigator', 'localStorage', 'location', script);
    fn({ languages, language: languages[0] }, { getItem: () => saved ?? null }, { replace: (u) => (target = u) });
    return target;
  };
  assert.equal(run(['en-US']), './en/index.html');
  assert.equal(run(['es-MX', 'en']), './es/index.html');
  assert.equal(run(['ja']), './es/index.html');
  assert.equal(run(['es-CO'], 'en'), './en/index.html'); // la elección guardada gana al dispositivo
});
