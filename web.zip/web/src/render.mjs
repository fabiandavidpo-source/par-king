import { icon } from './icons.mjs';

export const PAGES = [
  { key: 'home', file: 'index.html' },
  { key: 'how', file: 'how-it-works.html' },
  { key: 'owners', file: 'owners.html' },
  { key: 'about', file: 'about.html' },
];
const fileOf = (key) => PAGES.find((p) => p.key === key).file;

const esc = (value) =>
  String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const logo = () => '<img src="../assets/logo.svg" alt="" width="34" height="32">';

// ── Piezas ──────────────────────────────────────────────────────────────────

function storeBadges(c) {
  const badge = (name) =>
    `<span class="badge-store" aria-disabled="true"><span class="badge-small">${esc(c.badges.soon)}</span><span class="badge-name">${esc(name)}</span></span>`;
  return `<div class="badges">${badge(c.badges.ios)}${badge(c.badges.android)}</div><p class="badges-note">${esc(c.badges.note)}</p>`;
}

function benefitCards(items) {
  return `<ul class="cards">${items
    .map((b) => `<li class="card"><span class="card-icon">${icon(b.icon)}</span><h3>${esc(b.title)}</h3><p>${esc(b.text)}</p></li>`)
    .join('')}</ul>`;
}

function faq(items) {
  return `<div class="faq">${items
    .map((f) => `<details class="faq-item"><summary>${esc(f.q)}</summary><p>${esc(f.a)}</p></details>`)
    .join('')}</div>`;
}

function faqJsonLd(items) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })),
  };
  return `<script type="application/ld+json">${JSON.stringify(data).replace(/</g, '\\u003c')}</script>`;
}

function phoneHero(c) {
  const m = c.home.mock;
  return `<div class="phone" aria-hidden="true">
    <div class="phone-notch"></div>
    <div class="screen map-screen">
      <div class="search-bar">${esc(m.search)}</div>
      <div class="map">
        <span class="pin" style="left:18%;top:22%">${esc(m.price)}</span>
        <span class="pin" style="left:58%;top:12%">$5.000</span>
        <span class="pin pin-main" style="left:36%;top:48%">${esc(m.price)}</span>
        <span class="pin" style="left:62%;top:62%">$6.500</span>
      </div>
      <div class="sheet">
        <strong>${esc(m.name)}</strong>
        <span class="ok">${esc(m.spots)} · ${esc(m.price)}</span>
        <span class="btn-mock">${esc(m.reserve)}</span>
      </div>
    </div>
  </div>`;
}

function stepScreens(c) {
  const s = c.how.screens;
  const m = c.home.mock;
  return [
    `<div class="search-bar">${esc(s.search)}</div>
     <div class="map"><span class="pin" style="left:16%;top:24%">${esc(m.price)}</span><span class="pin pin-main" style="left:40%;top:50%">${esc(m.price)}</span><span class="pin" style="left:62%;top:20%">$5.000</span></div>
     <div class="sheet"><strong>${esc(m.name)}</strong><span class="ok">${esc(m.spots)}</span></div>`,
    `<h4>${esc(s.pickTime)}</h4>
     <div class="chips"><span class="chip on">${esc(s.today)}</span><span class="chip">${esc(s.tomorrow)}</span></div>
     <div class="chips"><span class="chip on">${esc(s.hours)}</span></div>
     <div class="total"><span>${esc(s.total)}</span><strong>${esc(s.price)}</strong></div>
     <span class="btn-mock">${esc(s.continue)}</span>`,
    `<h4>${esc(s.signIn)}</h4>
     <span class="btn-mock dark">${esc(s.apple)}</span>
     <span class="btn-mock outline">${esc(s.google)}</span>
     <p class="mini">${esc(s.later)}</p>`,
    `<h4>${esc(s.confirm)}</h4>
     <div class="countdown">14:59</div>
     <span class="btn-mock">${esc(s.confirmCta)}</span>
     <span class="btn-mock outline">${esc(s.checkIn)}</span>
     <span class="done">${icon('check')} ${esc(s.ready)}</span>`,
  ];
}

function stepper(c) {
  const how = c.how;
  const screens = stepScreens(c);
  return `<div class="stepper" data-stepper>
    <ol class="steps" role="tablist" aria-label="${esc(how.h1)}">
      ${how.steps
        .map(
          (s, i) => `<li>
        <button type="button" role="tab" id="tab-${i + 1}" aria-controls="screen-${i + 1}" aria-selected="${i === 0}" tabindex="${i === 0 ? 0 : -1}" data-step="${i + 1}">
          <span class="n" aria-label="${esc(how.stepLabel)} ${i + 1}">${i + 1}</span>
          <span class="st"><strong>${esc(s.title)}</strong><span class="time">~${esc(s.time)}</span></span>
        </button>
        <p>${esc(s.text)}</p>
      </li>`,
        )
        .join('')}
    </ol>
    <div class="phone" aria-live="polite">
      <div class="phone-notch"></div>
      ${screens
        .map(
          (html, i) =>
            `<div class="screen step-screen${i === 0 ? ' active' : ''}" role="tabpanel" id="screen-${i + 1}" aria-labelledby="tab-${i + 1}" ${i === 0 ? '' : 'data-inactive'}>${html}</div>`,
        )
        .join('')}
    </div>
  </div>`;
}

function ctaBand(title, text, c, dark = true) {
  return `<section class="band ${dark ? 'band-ink' : 'band-gold'}"><div class="wrap center"><h2>${esc(title)}</h2><p>${esc(text)}</p>${storeBadges(c)}</div></section>`;
}

// ── Estructura común ────────────────────────────────────────────────────────

function header(c, lang, pageKey, languages) {
  const nav = PAGES.map(
    (p) => `<a href="./${p.file}"${p.key === pageKey ? ' aria-current="page"' : ''}>${esc(c.nav[p.key])}</a>`,
  ).join('');
  const switcher = languages
    .map((l) =>
      l.code === lang
        ? `<span class="lang-current" aria-current="true" lang="${l.code}">${esc(l.short)}</span>`
        : `<a href="../${l.code}/${fileOf(pageKey)}" hreflang="${l.code}" lang="${l.code}" data-lang="${l.code}" title="${esc(l.name)}">${esc(l.short)}</a>`,
    )
    .join('');
  return `<header class="site-header">
    <div class="wrap bar">
      <a class="brand" href="./index.html" aria-label="${esc(c.nav.homeLabel)}">${logo()}<span class="brand-name">par-<span>king</span></span></a>
      <button type="button" class="nav-toggle" aria-expanded="false" aria-controls="site-nav"><span class="bars" aria-hidden="true"></span><span class="sr">${esc(c.nav.menu)}</span></button>
      <nav id="site-nav" class="site-nav" aria-label="${esc(c.nav.primary)}">
        ${nav}
        <span class="lang-switch" role="group" aria-label="${esc(c.nav.language)}">${switcher}</span>
      </nav>
    </div>
  </header>`;
}

function footer(c, lang, languages, year) {
  const nav = PAGES.map((p) => `<a href="./${p.file}">${esc(c.nav[p.key])}</a>`).join('');
  return `<footer class="site-footer">
    <div class="wrap">
      <div class="foot-top"><a class="brand" href="./index.html" aria-label="${esc(c.nav.homeLabel)}">${logo()}<span class="brand-name">par-<span>king</span></span></a><nav class="foot-nav" aria-label="${esc(c.nav.primary)}">${nav}</nav></div>
      <p class="foot-note">${esc(c.site.footerNote)}</p>
      <p class="foot-copy">© ${year} par-king. ${esc(c.site.rights)}</p>
    </div>
  </footer>`;
}

function head(c, lang, pageKey, languages, siteUrl) {
  const page = c[pageKey];
  const file = fileOf(pageKey);
  const alternates = siteUrl
    ? languages.map((l) => `<link rel="alternate" hreflang="${l.code}" href="${siteUrl}/${l.code}/${file}">`).join('\n  ') +
      `\n  <link rel="alternate" hreflang="x-default" href="${siteUrl}/index.html">\n  <link rel="canonical" href="${siteUrl}/${lang}/${file}">\n  <meta property="og:url" content="${siteUrl}/${lang}/${file}">`
    : '';
  return `<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${esc(page.title)}</title>
  <meta name="description" content="${esc(page.description)}">
  <meta name="theme-color" content="#15112B">
  <meta property="og:type" content="website">
  <meta property="og:site_name" content="par-king">
  <meta property="og:title" content="${esc(page.title)}">
  <meta property="og:description" content="${esc(page.description)}">
  <meta property="og:locale" content="${c.lang.locale}">
  <meta name="twitter:card" content="summary">
  <link rel="icon" href="../assets/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="../assets/styles.css">
  ${alternates}`;
}

function layout({ c, lang, pageKey, languages, body, extraHead = '', siteUrl, year }) {
  return `<!doctype html>
<html lang="${lang}">
<head>
  ${head(c, lang, pageKey, languages, siteUrl)}
  ${extraHead}
  <script>document.documentElement.classList.add('js')</script>
  <script src="../assets/app.js" defer></script>
</head>
<body>
  <a class="skip" href="#main">${esc(c.nav.skip)}</a>
  ${header(c, lang, pageKey, languages)}
  <main id="main">
${body}
  </main>
  ${footer(c, lang, languages, year)}
</body>
</html>
`;
}

// ── Páginas ─────────────────────────────────────────────────────────────────

const pages = {
  home(c) {
    const h = c.home;
    return `
<section class="hero hero-ink">
  <div class="wrap hero-grid">
    <div>
      <p class="eyebrow">${esc(h.eyebrow)}</p>
      <h1>${esc(h.h1a)} <span class="gold">${esc(h.h1b)}</span></h1>
      <p class="lead">${esc(h.lead)}</p>
      <div class="actions"><a class="btn btn-gold" href="./how-it-works.html">${esc(h.ctaPrimary)}</a><a class="btn btn-ghost" href="./owners.html">${esc(h.ctaSecondary)}</a></div>
      ${storeBadges(c)}
    </div>
    ${phoneHero(c)}
  </div>
</section>
<section class="section">
  <div class="wrap">
    <h2>${esc(h.benefitsTitle)}</h2><p class="section-lead">${esc(h.benefitsLead)}</p>
    ${benefitCards(h.benefits)}
  </div>
</section>
<section class="section section-soft">
  <div class="wrap">
    <h2>${esc(h.stepsTitle)}</h2><p class="section-lead">${esc(h.stepsLead)}</p>
    <ol class="quick-steps">${h.stepsShort.map((s, i) => `<li><span class="n">${i + 1}</span>${esc(s)}</li>`).join('')}</ol>
    <p class="center"><a class="btn btn-ink" href="./how-it-works.html">${esc(h.stepsCta)}</a></p>
  </div>
</section>
<section class="band band-gold">
  <div class="wrap owners-band">
    <div><p class="eyebrow dark">${esc(h.ownersBand.eyebrow)}</p><h2>${esc(h.ownersBand.title)}</h2><p>${esc(h.ownersBand.text)}</p></div>
    <a class="btn btn-ink" href="./owners.html">${esc(h.ownersBand.cta)}</a>
  </div>
</section>
${ctaBand(h.final.title, h.final.text, c)}`;
  },

  how(c) {
    const h = c.how;
    return `
<section class="hero hero-ink hero-small">
  <div class="wrap">
    <p class="eyebrow">${esc(h.eyebrow)}</p>
    <h1>${esc(h.h1)}</h1>
    <p class="lead">${esc(h.lead)}</p>
    <p class="total-time"><span>${esc(h.total)}</span> <strong>${esc(h.totalValue)}</strong></p>
  </div>
</section>
<section class="section"><div class="wrap">${stepper(c)}</div></section>
<section class="section section-soft"><div class="wrap narrow"><h2>${esc(h.extraTitle)}</h2><p class="section-lead">${esc(h.extraText)}</p></div></section>
<section class="section"><div class="wrap narrow"><h2>${esc(h.faqTitle)}</h2>${faq(h.faq)}</div></section>
${ctaBand(h.cta.title, h.cta.text, c)}`;
  },

  owners(c) {
    const o = c.owners;
    return `
<section class="hero hero-ink">
  <div class="wrap hero-grid">
    <div>
      <p class="eyebrow">${esc(o.eyebrow)}</p>
      <h1>${esc(o.h1a)} <span class="gold">${esc(o.h1b)}</span></h1>
      <p class="lead">${esc(o.lead)}</p>
      <div class="actions"><span class="btn btn-gold" aria-disabled="true">${esc(o.cta)}</span></div>
      <p class="badges-note">${esc(o.ctaNote)}</p>
    </div>
    <div class="owner-card" aria-hidden="true">
      ${icon('building')}
      <strong>${esc(c.home.mock.name)}</strong>
      <span class="ok">${esc(c.home.mock.spots)}</span>
      <span class="owner-rate">${esc(c.home.mock.price)}</span>
    </div>
  </div>
</section>
<section class="section"><div class="wrap"><h2>${esc(o.benefitsTitle)}</h2>${benefitCards(o.benefits)}</div></section>
<section class="section section-soft"><div class="wrap"><h2>${esc(o.stepsTitle)}</h2>
  <ol class="owner-steps">${o.steps.map((s, i) => `<li><span class="n">${i + 1}</span><div><strong>${esc(s.title)}</strong><p>${esc(s.text)}</p></div></li>`).join('')}</ol>
</div></section>
<section class="section"><div class="wrap narrow"><h2>${esc(o.faqTitle)}</h2>${faq(o.faq)}</div></section>
${ctaBand(o.final.title, o.final.text, c)}`;
  },

  about(c) {
    const a = c.about;
    return `
<section class="hero hero-ink hero-small">
  <div class="wrap"><p class="eyebrow">${esc(a.eyebrow)}</p><h1>${esc(a.h1)}</h1><p class="lead">${esc(a.lead)}</p></div>
</section>
<section class="section"><div class="wrap two">
  <article class="big-card"><h2>${esc(a.missionTitle)}</h2><p>${esc(a.mission)}</p></article>
  <article class="big-card big-card-gold"><h2>${esc(a.visionTitle)}</h2><p>${esc(a.vision)}</p></article>
</div></section>
<section class="section section-soft"><div class="wrap"><h2>${esc(a.valuesTitle)}</h2>${benefitCards(a.values)}</div></section>
<section class="band band-ink"><div class="wrap center"><h2>${esc(a.cta.title)}</h2>
  <div class="actions center-actions"><a class="btn btn-gold" href="./how-it-works.html">${esc(a.cta.drivers)}</a><a class="btn btn-ghost" href="./owners.html">${esc(a.cta.owners)}</a></div>
</div></section>`;
  },
};

export function renderPage({ content, lang, pageKey, languages, siteUrl = '', year = new Date().getFullYear() }) {
  const c = content[lang];
  const extraHead = pageKey === 'how' ? faqJsonLd(c.how.faq) : pageKey === 'owners' ? faqJsonLd(c.owners.faq) : '';
  return layout({ c, lang, pageKey, languages, body: pages[pageKey](c), extraHead, siteUrl, year });
}

/** Página de entrada: elige el idioma del dispositivo (o el que la persona eligió antes) y redirige. */
export function renderRoot({ languages, pickLanguageSource, fallback, siteUrl = '' }) {
  const links = languages.map((l) => `<a href="./${l.code}/index.html" hreflang="${l.code}" lang="${l.code}">${esc(l.name)}</a>`).join(' · ');
  const codes = JSON.stringify(languages.map((l) => l.code));
  const alternates = siteUrl ? languages.map((l) => `<link rel="alternate" hreflang="${l.code}" href="${siteUrl}/${l.code}/index.html">`).join('\n  ') : '';
  return `<!doctype html>
<html lang="${fallback}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>par-king</title>
  <meta name="theme-color" content="#15112B">
  <link rel="icon" href="./assets/favicon.svg" type="image/svg+xml">
  ${alternates}
  <link rel="stylesheet" href="./assets/styles.css">
  <script>
    (function () {
      ${pickLanguageSource}
      var supported = ${codes};
      var saved = null;
      try { saved = localStorage.getItem('par-king.lang'); } catch (e) {}
      var preferred = (navigator.languages && navigator.languages.length ? Array.prototype.slice.call(navigator.languages) : [navigator.language]);
      var lang = supported.indexOf(saved) !== -1 ? saved : pickLanguage(preferred, supported, '${fallback}');
      location.replace('./' + lang + '/index.html');
    })();
  </script>
</head>
<body class="root">
  <main class="root-box"><img src="./assets/logo.svg" alt="" width="72" height="67"><p class="root-name">par-<span>king</span></p><p class="root-links">${links}</p></main>
</body>
</html>
`;
}
