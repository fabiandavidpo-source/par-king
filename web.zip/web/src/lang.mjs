/** Idiomas con sitio propio. Para agregar uno: crear `src/content/<código>.json` con las mismas claves y añadirlo aquí. */
export const SUPPORTED = ['es', 'en'];
export const FALLBACK = 'es';

/**
 * Elige el idioma según las preferencias del dispositivo (p. ej. `navigator.languages`).
 * Toma el primero que tenga sitio ("en-US" → "en"); si ninguno, el idioma por defecto.
 * IMPORTANTE: se inserta tal cual en la página de entrada, así que no debe usar nada de fuera de la función.
 */
export function pickLanguage(candidates, supported = ['es', 'en'], fallback = 'es') {
  for (const candidate of candidates || []) {
    const base = String(candidate).toLowerCase().split(/[-_]/)[0];
    if (supported.indexOf(base) !== -1) return base;
  }
  return fallback;
}
